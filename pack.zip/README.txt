The emoji images in this resource pack are used from Twemoji which are licensed by CC BY 4.0.

This resource pack is also licensed by CC BY 4.0

The license for this resource pack can be found at https://raw.githubusercontent.com/James-Bennett-295/AndrosDiscordEmojis/master/LICENSE

Credits: Androkai (https://androkai.net/).
